package com.princecar.userapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
